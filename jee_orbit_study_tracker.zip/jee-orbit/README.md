# JEE Orbit — Study Tracker

A responsive, installable, offline-first PWA for tracking Class 11 JEE preparation.

## Included
- Class 11 Physics, Chemistry and Mathematics chapter tracker
- Theory, notes, practice, PYQ and revision checklist per chapter
- Completion status, mastery score and weak-chapter flag
- Daily study-hour/question targets and session log
- Spaced revision queue (1, 3, 7, 14, 30 days)
- Weekly study overview, subject progress, question counts and test scores
- JSON backup export
- Local browser storage and service-worker offline cache

## Run locally
A PWA service worker needs HTTPS or localhost. From this folder run:
```bash
python -m http.server 8000
```
Then open http://localhost:8000 in a browser.

## Install on Android
1. Host the folder on an HTTPS static host (GitHub Pages is one option).
2. Open the published URL in Chrome.
3. Use the browser menu → **Install app** or **Add to Home screen**.
4. Open once online to cache the app for offline use.

## Data and limitations
- Study data is stored in localStorage on this browser/device, not synced across devices.
- Use **Export backup** on the Tests & scores page to save a JSON backup.
- Browser notifications are permission-based and may not run when the app is closed.
- Class 12 chapters are not preloaded yet, per the requested Class 11-first approach. The code can be extended with a Class 12 chapter dataset.
- This app tracks progress; it does not automatically validate syllabus completion or calculate official JEE predictions.
